# Spots

An image sharing site

## Decription

This is a project where you can edit you're profile and add images with descriptions about the images. Yu can also like images if you want to save them for later.

## Tech Stack

-html
-css
-responsize design
-mobile view
-media queries

## Project Video

https://drive.google.com/file/d/1Jyu-_D8q_f7_nHr57D64ateDAZhQttGu/view?usp=sharing

## Deployment

This website is deployed to github pages
-deployment link:https://huntermelrose831.github.io/se_project_spots
